#' ---
#' title: "V1_Pipeline"
#' author: "K M Susong"
#' 
#' ---
#'
#' Overview
#' ========
#' 08-09-2025: Added source script for seasonal baseline.
#' 

library(dplyr)
library(lubridate)
library(purrr)

#------ Step 1: start log

# create run directory 
dir.create(paste0("V1/Output/",format(Sys.Date(), "%Y_%m_%d")))

# define log file path 

# start log process 

#------ Step 2: Open Data
## this opens all opendengue, paho, searo and who data
source("V1/Scripts/data_sourcing/01_dengue_data.R")

# ----- Step 3: determine historic average and baseline seasonality

# Select the source of historic data
source("V1/Scripts/data_sourcing/01_Choosing_WHO_or_OpenDengue_data.R")

# Define the combination of WHO and Opendengue data for historical data
source("V1/Scripts/data_sourcing/02_Combining_WHO_and_OpenDengue_data.R")

# calculate average season 
source("V1/Scripts/seasonal_baseline/02_identify_seasonal_baseline.R") 


#------ Step 4: Data selection and Backfilling  

source("V1/Scripts/backfilling/02_PAHO_monthly_cases_and_source_selection.R")

#------ Step 5: Nowcasting to Date 

source("V1/Scripts/nowcasting/03_proportion_nowcast.R")


#------ Step 6: Post-processing 


# ---- Regional monthly summary ----

# add region back in:

region_map <- OD_national %>%
  mutate(
    country = str_to_title(country) # fix ALL CAP
  ) %>%
  dplyr::select(country, Region) %>%
  unique()

data <- merge(data,region_map)

region_levels <- c(
  "South America",
  "Caribbean",
  "Pacific Islands",
  "South Asia",
  "Central America & Mexico",
  "Sub-Saharan Africa",
  "East & Southeast Asia",
  "Europe, Middle East & North Africa"
)

data <- data %>%
  mutate(Region = factor(Region, levels = region_levels))


#  Regional Summary 

region_summary <- data %>%
  group_by(Region, Year, Month) %>%
  reframe(
    cases = sum(cases, na.rm = TRUE),
    Ave_season_monthly_cases = sum(Ave_season_monthly_cases, na.rm = TRUE),
    Ave_season_monthly_cum_cases = sum(Ave_season_monthly_cum_cases, na.rm = TRUE),
    Predicted_total_seasonal_cases = sum(Predicted_total_seasonal_cases, na.rm = TRUE),
    # Optionally include averages of proportions or percentiles if needed
    Ave_cum_monthly_proportion = mean(Ave_cum_monthly_proportion, na.rm = TRUE),
    Ave_monthly_proportion = mean(Ave_monthly_proportion, na.rm = TRUE),
    percentile_most_recent = mean(percentile_most_recent, na.rm = TRUE),
    n_countries = n_distinct(iso3)
  ) %>%
  ungroup() %>%
  mutate(
    date = as.Date(paste0(Year, "-", Month, "-01")))

#----- Step 7: Save outputs 
# # ------ Save output df 


write_csv(current_data, file = paste0("V1/Output/", format(Sys.Date(), "%Y_%m_%d"),"/DENV_cases_backfill_output.csv"))
write.csv(data, file = paste0("V1/Output/", format(Sys.Date(), "%Y_%m_%d"),"/DENV_cases_nowcast_output.csv"))
write.csv(full_data_average_season, file = paste0("V1/Output/", format(Sys.Date(), "%Y_%m_%d"),"/DENV_average_season.csv"))
